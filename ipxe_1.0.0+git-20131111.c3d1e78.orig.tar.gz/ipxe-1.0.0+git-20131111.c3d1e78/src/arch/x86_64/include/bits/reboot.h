#ifndef _BITS_REBOOT_H
#define _BITS_REBOOT_H

/** @file
 *
 * x86_64-specific reboot API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

#endif /* _BITS_REBOOT_H */
