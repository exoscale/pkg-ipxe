#ifndef _BITS_ACPI_H
#define _BITS_ACPI_H

/** @file
 *
 * x86-specific ACPI API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#include <ipxe/rsdp.h>

#endif /* _BITS_ACPI_H */
