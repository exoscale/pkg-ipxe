#ifndef _IPXE_ACPIPWR_H
#define _IPXE_ACPIPWR_H

/** @file
 *
 * ACPI power off
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

extern int acpi_poweroff ( void );

#endif /* _IPXE_ACPIPWR_H */
